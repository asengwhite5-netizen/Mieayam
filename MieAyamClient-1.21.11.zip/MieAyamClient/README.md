# Mie Ayam Client (Fabric 1.21.11)

Menu GUI: tekan Right Shift (bisa diubah di Controls > MieAyamClient)
Toggle cepat: J = SlamStun, K = AntiInvis, L = Hitbox, M = Brightness

Build: JDK 21 + Gradle 9.2.1 -> `gradle build`
Jar: build/libs/MieAyamClient-1.0.0.jar -> folder mods (butuh Fabric Loader 0.18.1+ dan Fabric API).
