package com.mieayam.client;

import com.mieayam.client.gui.MieAyamScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MieAyamClient implements ClientModInitializer {
    public static final String NAME = "Mie Ayam Client";

    // Module states
    public static boolean slamStun = true;
    public static boolean antiInvis = true;
    public static boolean hitbox = true;
    public static boolean brightness = true;

    // Hitbox expand (blok) - cuma ngaruh ke crosshair/targeting di client
    public static float hitboxExpand = 0.4f;

    private static boolean swapToMacePending = false;
    // Auto click mace setelah axe stun
    private static PlayerEntity pendingVictim = null;
    private static PlayerEntity autoVictim = null;
    private static int autoTicks = 0;
    private static boolean autoAttacking = false;
    private static boolean nightVisionApplied = false;

    private static KeyBinding kGui, kSlam, kInvis, kHitbox, kBright;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("mieayamclient", "main"));
        kGui    = KeyBindingHelper.registerKeyBinding(new KeyBinding("Open GUI",   InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        kSlam   = KeyBindingHelper.registerKeyBinding(new KeyBinding("SlamStun",   InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, cat));
        kInvis  = KeyBindingHelper.registerKeyBinding(new KeyBinding("AntiInvis",  InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, cat));
        kHitbox = KeyBindingHelper.registerKeyBinding(new KeyBinding("Hitbox",     InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_L, cat));
        kBright = KeyBindingHelper.registerKeyBinding(new KeyBinding("Brightness", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, cat));

        ClientTickEvents.END_CLIENT_TICK.register(MieAyamClient::tick);
    }

    private static void tick(MinecraftClient mc) {
        while (kGui.wasPressed()) mc.setScreen(new MieAyamScreen());

        if (mc.player == null) return;

        while (kSlam.wasPressed())   { slamStun   = !slamStun;   msg(mc, "SlamStun",  slamStun); }
        while (kInvis.wasPressed())  { antiInvis  = !antiInvis;  msg(mc, "AntiInvis", antiInvis); }
        while (kHitbox.wasPressed()) { hitbox     = !hitbox;     msg(mc, "Hitbox",    hitbox); }
        while (kBright.wasPressed()) { brightness = !brightness; msg(mc, "Brightness",brightness); }

        // Brightness (night vision visual, client only)
        if (brightness) {
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 500, 0, false, false, false));
            nightVisionApplied = true;
        } else if (nightVisionApplied) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }

        // SlamStun: setelah axe stun, pindah ke mace. Slam otomatis klik.
        if (swapToMacePending) {
            swapToMacePending = false;
            int mace = findHotbar(mc.player, true);
            if (mace != -1) {
                mc.player.getInventory().setSelectedSlot(mace);
                autoVictim = pendingVictim;
                autoTicks = 60;
            }
            pendingVictim = null;
        }

        // Auto click: setelah pindah ke mace, serang target otomatis begitu cooldown siap
        if (autoVictim != null) {
            autoTicks--;
            if (autoTicks <= 0 || !autoVictim.isAlive() || mc.interactionManager == null) {
                autoVictim = null;
            } else if (mc.player.getMainHandStack().isOf(Items.MACE)
                    && mc.targetedEntity == autoVictim
                    && mc.player.getAttackCooldownProgress(0.5f) >= 1.0f) {
                autoAttacking = true;
                try {
                    mc.interactionManager.attackEntity(mc.player, autoVictim);
                    mc.player.swingHand(Hand.MAIN_HAND);
                } finally {
                    autoAttacking = false;
                }
                autoVictim = null;
            }
        }
    }

    /** Dipanggil dari mixin saat kamu klik serang entity. Tidak melakukan attack otomatis. */
    public static void onAttack(PlayerEntity player, Entity target) {
        if (!slamStun || autoAttacking) return;
        if (!(target instanceof PlayerEntity victim) || !victim.isBlocking()) return;

        int axe = findHotbar(player, false);
        int mace = findHotbar(player, true);
        if (axe == -1 || mace == -1) return;

        if (!player.getMainHandStack().isIn(ItemTags.AXES)) {
            player.getInventory().setSelectedSlot(axe);
        }
        swapToMacePending = true;
        pendingVictim = victim;
    }

    private static int findHotbar(PlayerEntity p, boolean mace) {
        for (int i = 0; i < 9; i++) {
            var s = p.getInventory().getStack(i);
            if (mace ? s.isOf(Items.MACE) : s.isIn(ItemTags.AXES)) return i;
        }
        return -1;
    }

    private static void msg(MinecraftClient mc, String name, boolean on) {
        mc.player.sendMessage(Text.literal("§b[" + NAME + "] §f" + name + ": " + (on ? "§aON" : "§cOFF")), true);
    }
}
